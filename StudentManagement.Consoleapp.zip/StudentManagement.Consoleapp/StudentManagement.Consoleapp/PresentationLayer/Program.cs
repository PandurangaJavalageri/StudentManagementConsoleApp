﻿using StudentManagement.Consoleapp.datalayer;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StudentManagement.Consoleapp
{
    internal class Program
    { 
        static Istudentsrepo repository = new Repository();
    
        static void Main(string[] args)
        {
            //collect student data from user and store into db
            /*Student student = new Student
            {
                FirstName = "R",
                LastName = "k",
                Dob = DateTime.Parse("01/10/2009"),
                Email = "abc@gmail.com",
                Mobile = "43677634872",
                Course = "cse"
            };
            SqlConnection conn = new SqlConnection();
            conn.ConnectionString = @"Server = (localdb)\mssqllocaldb;Initial Catalog=new db;Integrated Security=true";
            conn.Open();
            Console.WriteLine("Connected....");
            string sqlInsert = $"insert into studentstable values('{student.FirstName}','{student.LastName}','{student.Dob}','{student.Email}','{student.Mobile}','{student.Course}')";
            SqlCommand cmd=new SqlCommand(sqlInsert, conn);
            //cmd.Connection = conn;
            cmd.ExecuteNonQuery();
            conn.Close();
            Console.WriteLine("saved...");*/
            


                while (true)
                {
                    Console.WriteLine("Student Manager");
                    Console.WriteLine("=====================");
                    Console.WriteLine("1. Create student entry");
                    Console.WriteLine("2. Get All students");
                    Console.WriteLine("3. Get student details  By RollNo");
                    Console.WriteLine("4. Edit student details");
                    Console.WriteLine("5. Delete student details");
                    Console.WriteLine("6. Exit");
                    Console.WriteLine("----------------------");
                    Console.Write("Enter your choice [1-6] :");
                    int choice = int.Parse(Console.ReadLine());

                    switch (choice)
                    {
                        case 1: CreateContact(); break;
                        case 2: GetAllContacts(); break;
                        case 3: GetContactById(); break;
                        case 4: EditContact(); break;
                        case 5: DeleteContact(); break;
                        case 6: Environment.Exit(0); break;
                        default: Console.WriteLine("Invalid option"); break;
                    

                }

            }
        }

        private static void DeleteContact()
        {
            Console.WriteLine("enter the id");
            int id = int.Parse(Console.ReadLine());
            repository.DeleteContactById(id);
        }

        private static void EditContact()
        {
           Student student = new Student();
            Console.WriteLine("enter  first name");
            student.FirstName = Console.ReadLine();
            Console.WriteLine("enter Last Name");
            student.LastName = Console.ReadLine();
            Console.WriteLine("enter date of birth");
            student.Dob=DateTime.Parse(Console.ReadLine());
            Console.WriteLine("enter email id");
            student.Email = Console.ReadLine();
            Console.WriteLine("enter mobile no");
            student.Mobile = Console.ReadLine();
            Console.WriteLine("enter course");
            student.Course = Console.ReadLine();
            Console.WriteLine("enter roll no");
            int rno=int.Parse(Console.ReadLine());
            repository.UpdateContactById(student, rno);
        }

        private static void GetContactById()
        {
            Console.WriteLine("enter the roll no");
            int rno=int.Parse(Console.ReadLine());
            Student student = repository.GetContactById(rno);
            if(student != null)
            {
                Console.WriteLine(student.FirstName+student.LastName);
            }
        }

        private static void GetAllContacts()
        {
           List<Student> students = repository.GetAllContact();
            foreach (Student student in students)
            {
                Console.WriteLine("hi");
                Console.WriteLine(student.FirstName+student.LastName);
            }
        }

        private static void CreateContact()
        {
            Student student = new Student();
            Console.WriteLine("enter  first name");
            student.FirstName = Console.ReadLine();
            Console.WriteLine("enter Last Name");
            student.LastName = Console.ReadLine();
            Console.WriteLine("enter date of birth");
            string userInputDate = Console.ReadLine();

            DateTime userDate;

            if (DateTime.TryParse(userInputDate, out userDate))
            {
                student.Dob = userDate;

            }
            else
            {
                Console.WriteLine("Invalid date format. Please enter a valid date.");
                return;
            }
            Console.WriteLine("enter email id");
            student.Email = Console.ReadLine();
            Console.WriteLine("enter mobile no");
            student.Mobile = Console.ReadLine();
            Console.WriteLine("enter course");
            student.Course = Console.ReadLine();
            Console.WriteLine("enter roll no");
            student.RollNo=int.Parse(Console.ReadLine());
            repository.Save(student);

        }
    }
}

