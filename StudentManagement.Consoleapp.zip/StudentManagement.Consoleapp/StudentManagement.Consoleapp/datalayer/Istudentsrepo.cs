﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StudentManagement.Consoleapp.datalayer
{
    public interface Istudentsrepo
    {
        void Save(Student contact);
        void UpdateContactById(Student contact,int Roll);
        void DeleteContactById(int Roll);
        List<Student> GetAllContact();
        Student GetContactById(int Roll);

    }
}
