﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StudentManagement.Consoleapp.datalayer
{
    public class Repository : Istudentsrepo
    {
        SqlConnection conn = new SqlConnection();
        
        public void DeleteContactById(int id)
        {
            conn.ConnectionString = @"Server = (localdb)\mssqllocaldb;Initial Catalog=new db;Integrated Security=true";
            conn.Open();
            Console.WriteLine("Connected....");
            string sqldel = $"delete from Table_1  where RollNo={id}";
            SqlCommand cmd = new SqlCommand(sqldel, conn);
            conn.Close();
        }

        public List<Student> GetAllContact()
        {
            conn.ConnectionString = @"Server = (localdb)\mssqllocaldb;Initial Catalog=new db;Integrated Security=true";
            conn.Open();
            Console.WriteLine("Connected....");
            string sqlret = $"select *from Table_1";
            SqlCommand cmd = new SqlCommand(sqlret, conn);
            SqlDataReader reader = cmd.ExecuteReader();
            
            List<Student> list = new List<Student>();
            while (reader.Read())
            {
                Student student = new Student();
               
                student.FirstName = reader["FirstName"].ToString();
                student.LastName = reader["LastName"].ToString() ;
                student.Email = reader["Email"].ToString();
                student.Course = reader["Course"].ToString();
                student.Mobile = reader["Mobile"].ToString();

                list.Add(student);
            }
            conn.Close();
            return list;    
           
           
        }

        public Student GetContactById(int id)
        {
            conn.ConnectionString = @"Server = (localdb)\mssqllocaldb;Initial Catalog=new db;Integrated Security=true";
            conn.Open();
            Console.WriteLine("Connected....");
            string sqlret = $"select * from Table_1 where RollNo={id}";
            SqlCommand cmd = new SqlCommand(sqlret, conn);
            SqlDataReader reader = cmd.ExecuteReader();
            Student student = new Student();
            reader.Read();
            student.FirstName = reader["FirstName"].ToString();
            student.LastName = reader["LastName"].ToString();
            student.Email = reader["Email"].ToString();
            student.Course = reader["Course"].ToString();
            student.Mobile = reader["Mobile"].ToString();
            conn.Close();
            return student;

        }

        public void Save(Student student)
        {
            SqlConnection conn = new SqlConnection();
            conn.ConnectionString = @"Server = (localdb)\mssqllocaldb;Initial Catalog=new db;Integrated Security=true";
            conn.Open();
            
            string sqlInsert = $"insert into Table_1 values({student.RollNo},'{student.FirstName}','{student.LastName}','{student.Dob}','{student.Email}','{student.Mobile}','{student.Course}')";
            SqlCommand cmd = new SqlCommand(sqlInsert, conn);
            

            cmd.ExecuteNonQuery();
            conn.Close();
        }

        public void UpdateContactById(Student student, int id)
        {
            SqlConnection conn = new SqlConnection();
            conn.ConnectionString = @"Server = (localdb)\mssqllocaldb;Initial Catalog=new db;Integrated Security=true";
            conn.Open();



           string sqlInsert = $"update Table_1 set FirstName='{student.FirstName}',LastName='{student.LastName}',Mobile='{student.Mobile}',Course='{student.Course}',Dob='{student.Dob}',Email='{student.Email}' where RollNo={id} ";
          

            
            using (SqlCommand cmd = new SqlCommand(sqlInsert, conn))
            {
                cmd.Connection = conn;
              
                cmd.ExecuteNonQuery();
            }
           
            conn.Close();
        }
    }

}
