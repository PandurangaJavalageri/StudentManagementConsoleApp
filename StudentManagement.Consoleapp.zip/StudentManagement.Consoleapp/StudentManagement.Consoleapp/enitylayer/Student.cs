﻿using System;

namespace StudentManagement.Consoleapp
{
    public class Student
    {
        public string FirstName {  get; set; }
        public string LastName { get; set; }
        public DateTime Dob { get; set; }
        public string Email {  get; set; }
        public string Mobile {  get; set; }
        public string Course {  get; set; }
        public int RollNo {  get; set; }

    }
}